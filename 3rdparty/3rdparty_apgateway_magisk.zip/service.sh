#!/system/bin/sh
# service.sh — runs late in boot (after data is decrypted & mounted)
#
# Keeps the priv-app APK in sync when the user updates via 'adb install -r'.
# The updated APK goes to /data/app/ but the priv-app base in the Magisk
# overlay becomes stale.  This script copies the latest APK so the overlay
# is correct on the NEXT reboot.
#
# Also logs CAPTURE_AUDIO_OUTPUT grant status for debugging.

MODDIR="${0%/*}"
TAG="GatewayMagisk"

PRIV_DIR="$MODDIR/system/priv-app/Gateway"
PRIV_APK="$PRIV_DIR/Gateway.apk"

# ── Sync APK ──────────────────────────────────────────
# pm path returns the currently-active APK (may be /data/app/ update)
APK_PATH=$(pm path com.callagent.gateway 2>/dev/null | head -1 | sed 's/^package://')

if [ -n "$APK_PATH" ] && [ -f "$APK_PATH" ]; then
    if [ ! -f "$PRIV_APK" ]; then
        # No priv-app APK yet — copy it
        mkdir -p "$PRIV_DIR"
        cp "$APK_PATH" "$PRIV_APK"
        chmod 644 "$PRIV_APK"
        log -t "$TAG" "Created priv-app APK from $APK_PATH (reboot needed)"
    elif ! cmp -s "$APK_PATH" "$PRIV_APK" 2>/dev/null; then
        # APK was updated via adb install — sync it
        cp "$APK_PATH" "$PRIV_APK"
        chmod 644 "$PRIV_APK"
        log -t "$TAG" "Synced updated APK from $APK_PATH (reboot needed for priv-app refresh)"
    else
        log -t "$TAG" "Priv-app APK is up to date"
    fi
else
    log -t "$TAG" "Gateway app not installed — nothing to sync"
fi

# ── Log permission status ─────────────────────────────
PERM_DUMP=$(dumpsys package com.callagent.gateway 2>/dev/null)
if echo "$PERM_DUMP" | grep -q "CAPTURE_AUDIO_OUTPUT.*granted=true"; then
    log -t "$TAG" "CAPTURE_AUDIO_OUTPUT: GRANTED"
else
    log -t "$TAG" "CAPTURE_AUDIO_OUTPUT: NOT GRANTED — check priv-app install, reboot may be needed"
    # Log the install location for debugging
    log -t "$TAG" "APK path: $APK_PATH"
    log -t "$TAG" "Priv-app: $(ls -la $PRIV_APK 2>/dev/null || echo 'missing')"
fi
