#!/system/bin/sh
# Magisk module installation script
# Installs the gateway app as a system priv-app with elevated permissions
# (required for CAPTURE_AUDIO_OUTPUT — telephony audio capture)

SKIPUNZIP=1

# Extract module files
ui_print "- Extracting module files"
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH

# ── Ensure APK is in priv-app ────────────────────────
# build.sh includes the APK in the zip, but if the module was built
# from git without build.sh, or if the user wants to update the APK
# independently, we fall back to copying the already-installed APK.

PRIV_DIR="$MODPATH/system/priv-app/Gateway"
PRIV_APK="$PRIV_DIR/Gateway.apk"

if [ -f "$PRIV_APK" ]; then
    ui_print "- APK found in module (from build.sh)"
else
    ui_print "- APK not in module, searching installed apps..."
    # Find the APK installed via 'adb install' or Play Store
    APK_PATH=$(pm path com.callagent.gateway 2>/dev/null | head -1 | sed 's/^package://')
    if [ -n "$APK_PATH" ] && [ -f "$APK_PATH" ]; then
        mkdir -p "$PRIV_DIR"
        cp "$APK_PATH" "$PRIV_APK"
        ui_print "- Copied installed APK to priv-app: $APK_PATH"
    else
        ui_print "! WARNING: Gateway APK not found!"
        ui_print "! Install the APK first (adb install gateway.apk),"
        ui_print "! then reinstall this Magisk module."
    fi
fi

# ── Set permissions ───────────────────────────────────
set_perm_recursive $MODPATH 0 0 0755 0644
if [ -d "$PRIV_DIR" ]; then
    set_perm_recursive $MODPATH/system/priv-app 0 0 0755 0644
fi

# Ensure module mount is never skipped
rm -f "$MODPATH/skip_mount"

ui_print "- SIP-GSM Gateway installed as priv-app"
ui_print "- Privileged permissions (CAPTURE_AUDIO_OUTPUT) configured"
ui_print "- Reboot required to activate"
